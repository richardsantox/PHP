<?php
	include 'conecta.php';

	$nome = "NOME INSERIDO";
	$idade = 26;
	$senha = "yhvasa";

	$consulta = $conexao->prepare("INSERT INTO cliente (nome, idade,senha) VALUES ('$nome','$idade','$senha')");

	//prepare ==> prepera a consulta SQL e retorna um indentificador de instrução a ser usado para operações adicionais na instrução. A consulta deve consistir em uma unica instrução SQL.

	$consulta->execute();

	//execute ==> Executa uma query que foi previamente preparada usando a função mysqli_prepare()
	?>