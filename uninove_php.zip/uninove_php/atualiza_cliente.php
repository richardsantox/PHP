<?php
	include 'conecta.php';
	//Dados a serem atualizados 
	$id = 4;
	$nome_novo = "NOME INSERIDO ATUALIZADO";

	$conculta = $conexao->prepare("UPDATE cliente set nome ='$nome_novo' WHERE id = 'id'");

	$consulta-> execute();
	
?>