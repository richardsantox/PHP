<?php
session_start(); 

if (
	(!isset($_SESSION['id'])==true)&&
	(!isset($_SESSION['nome'])==true)&&
	(!isset($_SESSION['email'])==true)){

	unset($_SESSION['id']);
	unset($_SESSION['nome']);
	unset($_SESSION['email']);
	header('location:index.html');
 }

ECHO "bem vindo a uma pagina bem vinda <br>";
echo "(mas nem tanto assim, por enquanto...)";


?>

<a href="sair.php">SAIR</a>