<?php
	include 'conecta.php';
	//Dados a serem removidos 
	$id = 4;

	$consulta = $conexao->prepare("DELETE FROM cliente WHERE id = '$id'");

	$consulta->execute();

?>