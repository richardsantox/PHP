

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-reboot.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <script type="text/javascript" src="../js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="../js/bootstrap.js"></script>
    <script src="https://kit.fontawesome.com/93d2e1d254.js" crossorigin="anonymous"></script>
</head>
       
        <div class="container">
            <br>
            <div class="card">
                <div class="card-body centro ">
                    <h5 class="card-title">&nbsp;Insira seu email e senha</h5>
                    <form class="centro" action="Processa.php" method="post">
                    
                        <div class="form-group"> 
                            <label for="nome-produto">Digite seu email</label>
                            <input class="form-control" type="text" name="email"><br>
                        </div>

                          <div class="form-group"> 
                            <label for="preco-produto">Digite sua senha</label>
                            <input class="form-control" type="text" name="senha"><br>
                        </div>
                        <br>
                        <hr>
                        <input type="submit" value="Login" class="btn btn-dark btn lg">
                    </form> 
                            
                </div>
            </div>      
        </div>
        
    </body>
</html>