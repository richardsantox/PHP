<!DOCTYPE html>
<html>

                    <?php
                    include 'conecta.php';
                    include 'cabecalho.php';

                    echo "<br><hr>";
                    session_start();
                    $nf = $_SESSION['nf'];
                    ?>

<div class="container">
    <br>
        <div class="card">  
            <div class="card-body centro">
                    <?php
                    $consulta = "SELECT * FROM itens_nf WHERE num_nf = '$nf'";

                    echo "<h1>NF: " . $nf . "</h1><br><hr>";
                    $total = 0;

                    foreach ($conexao -> query($consulta) as $linha) {
                        echo "Cod Produto: ".$linha['cod_produto']."<br>";
                        echo "Qtde: ".$linha['qtde']."<br>";
                        echo "Subtotal: ".$linha['subtotal']."<br>";
                        $total = $total + $linha['subtotal'];
                        echo "<hr>";
                    }
                    echo "<b>TOTAL DA NOTA R$ ".$total."</b><hr>";
                    ?>

                    <h5>O que deseja fazer?</h5>
                    <p><a href="seleciona_ultima_nf.php" class="btn btn-dark btn lg">Inserir outro produto</a></p>
                    <p><a href="finalizar.php?total=<?php echo $total;
                                                    ?>" class="btn btn-dark btn lg"> Finalizar nota fiscal</a></p>

        </div>
    </div>
</div>
                                                    
</body>
</html>