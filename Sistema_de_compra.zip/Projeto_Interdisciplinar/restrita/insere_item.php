<!DOCTYPE html>
<html>

<head>
    <title>Item da Nota Fiscal</title>
</head>

<body>
    <?php
    include 'conecta.php';
    echo "<br>";
    include 'cabecalho.php';


    session_start();
    $nf = $_SESSION['nf'];
    
    $id_prod = $_POST['produto_opcao'];
    $qtde_prod = $_POST['qtde'];

    $consulta = "SELECT preco,nome FROM produtos WHERE id = '$id_prod'";
    $consulta = $conexao->query($consulta);
    $linha = $consulta->fetch_assoc();
    //print_r($linha);
    $preco = $linha['preco'];
    $nome = $linha['nome'];

    $subtotal = $preco * $qtde_prod;

    ?>

        <div class="container">
            <br>
            <div class="card">  
                <div class="card-body centro">

                    <h5 class="card-title">&nbsp;Confirma item</h5>
                    <div>
                        <form class="centro" action="insere_item_nf.php" method="POST">
                            <div class="form-group">
                                <label for="id_produto"> ID produto</label>
                                <input class="form-control" tipe="text" name="id_prod" value="<?php echo $id_prod;?>" readonly="readonly">
                            </div>
                            
                               
                            <div class="form-group">
                                <label for="id_produto"> Produto</label>
                                <input class="form-control"  type="text" name="nome_prod" value="<?php echo $nome;
                                                                                  ?>" readonly="readonly">
                            </div>
                           

                            <div class="form-group">
                                <label for="id_produto"> Valor unitario</label>
                                <input class="form-control"  type="text" name="valor_unit" value="<?php echo $preco;
                                                                                            ?>" readonly="readonly">
                            </div>

                              <div class="form-group">
                                <label for="id_produto"> Quantidade</label>
                                <input class="form-control"  type="text" name="qtde" value="<?php echo $qtde_prod;
                                                                                    ?>" readonly="readonly">
                            </div>
                          
                             <div class="form-group">
                                <label for="id_produto"> Subtotal</label>
                                <input class="form-control"  type="text" name="subtotal" value="<?php echo $subtotal;
                                                                                    ?>" readonly="readonly">
                            </div>
                            

                            <input class="btn btn-dark btn lg" type="submit" value="ADICIONAR PRODUTO">
                            
                        </div>

                </div>
            </div>
        </div>
</form>
</body>
</html>