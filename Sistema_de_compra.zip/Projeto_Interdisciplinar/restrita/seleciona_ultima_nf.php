
 <!DOCTYPE html>
 <html>
 <?php
	include 'cabecalho.php';
	include 'conecta.php';
	echo "<br><hr>";

	$consulta = "SELECT MAX(nf) as ultima FROM nota_fiscal";
	$consulta = $conexao->query($consulta);
	$linha = $consulta->fetch_assoc();
	$ultimo = $linha['ultima'];
	

	session_start();
	$_SESSION['nf'] = $ultimo;
?>
<br>
	<div class="container">
		<div class="card">	
			<div class="card-body centro">
			 	<form class="centro" action="insere_item.php?nf='<?php echo $ultimo; ?>'" method="post">
			 		<div class="form-group">
			 			<label for="codigo-nota">NF</label>
			 			<input class="form-control" type="text" value="<?php echo $ultimo; ?>">
			 		 </div>
			 		
			 		<div class="form-group"> 
			 			<label for="rotulo-produto">Produto</label>
			 			<select class="form-control" name="produto_opcao" id="produto_opcao">
			 				<?php

			 					$consulta = "SELECT * FROM produtos";
			 					foreach ($conexao -> query($consulta)as $linha) {
			 				?>
			 						<option value="<?php echo $linha['id'];?>"><?php echo $linha ['nome'];?></option>
			 				<?php
			 					}
			 				?>
			 			</select>
			 		</div>
			 		<div class="form-group">
			 			<label for="qtde-produto">Quantidade</label>
			 			 <input type="text" name="qtde">
			 		</div>
			 		<hr>
			 		<input type="submit" value="Adicionar" class="btn btn-dark btn lg">
			 	</form>
			</div>
		 </div>
	 </div>
 </body>
 </html>