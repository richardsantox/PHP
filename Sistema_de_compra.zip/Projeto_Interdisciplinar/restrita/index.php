<?php
session_start();

// $_SESSION['id'] 
// $_SESSION['nome'] 
// $_SESSION['email'] 
// $_SESSION['senha'] 

if ((!isset($_SESSION['id']) == true) && (!isset($_SESSION['nome']) == true) && (!isset($_SESSION['email']) == true) && (!isset($_SESSION['senha']) == true)) {
	header("Location: ../index.php");
}

?>


<!DOCTYPE html>
<html>

<?php
	include 'cabecalho.php';
?>
<br>
	<section> 
		<div class="container">
			<div class="card">
				<h4>&nbsp; Olá <?php echo $_SESSION['nome']; ?>, Bem vindo!</h4>
				    <div class="card-body">
					    <h5 class="card-title">&nbsp;Inicia uma nova venda</h5>
					
					   		<ul>
							<li>&nbsp;Ao clicar em <b>INICIAR VENDA</b>, o sistema irá gerar uma nova nota fiscal na tabela nota_fiscal sem o valor total.</li>
							<li>&nbsp;Na proxima tela será solicitado a data da NF.</li>
							<li>&nbsp;O valor total será atualizado após a inserção dos itens da nota fiscal.</li>
							</ul>	
							<hr>						
								<a href="data_nf.php" class="btn btn-dark btn lg">INICIAR VENDA</a>
							
					</div>
			</div>		
		</div>
	</section>

	<section> 
		<div class="container borda">
			<br>
			<br>
			<h5>Outras opções</h5>
			<hr>
			<div class="row">
				<div class="col-md-4 centro none ">
					<i class="fas fa-receipt tam" href="ver_nf.php"></i>
					<p><a href="ver_nf.php">Ver notas emitidas</a></p>
				</div>
				<div class="col-md-4 centro none">
					<i class="fas fa-clipboard-list tam" href="ver_produtos.php"></i>
					<p><a href="ver_produtos.php">Ver produtos</a></p>
				</div>
				<div class="col-md-4 centro none">	
					<i class="fas fa-edit tam" href="cadastrar_produto.php"></i>
					<p><a href="cadastrar_produto.php">Cadastrar produtos</a></p>
				</div>
			</div>
		</div>
	</section>
	
</body>

</html>