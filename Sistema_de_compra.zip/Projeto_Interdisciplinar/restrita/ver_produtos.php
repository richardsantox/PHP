<?php
include 'conecta.php';
include 'cabecalho.php';

?>
<div class="container">
    <br>
    <div class="card">
        <div class="card-body  ">
<?php


$consulta = "SELECT *FROM produtos";

foreach ($conexao->query($consulta) as $linha) {
    echo "<br>";
    echo "ID: " . $linha['id'] . "<br>";
    echo "Nome: " . $linha['nome'] . "<br>";
    echo "Valor: " . $linha['preco'] . "<br>";

    echo "<hr>";
    
}
echo "<br>";
?>
<p class="centro"><a href="index.php" class="btn btn-dark btn lg"> VOLTAR INICIO</a></p>
    	 </div>
    </div>
</div>