<?php
	include 'conecta.php';
 ?>

 <!DOCTYPE html>
 <html>
 <?php
	include 'cabecalho.php';
?>
 	

 	<section> 
		<div class="container">
			<br>
			<div class="card">
				<div class="card-body centro ">
					<form class="centro" action="gera_nf.php" method="post"> 
						<div class="form-group"> 
							<label for="exemplo-data"> Insira a data da venda</label>
					 		<input class="form-control" type="date" name="data">
					 		<hr>
						</div>
				 		<div class="form-group">
				 			<input type="submit" value="Continuar"class="btn btn-dark btn lg">
				 		</div>
			 		</form>
					   		
				</div>
			</div>		
		</div>
	</section>
 
 </body>
 </html>
 