<?php 
    include'conecta.php';
   include 'cabecalho.php';
?>
<div class="container">
    <br>
    <div class="card">
        <div class="card-body  ">
<?php  

    $consulta = "SELECT *FROM nota_fiscal";

    foreach ($conexao -> query($consulta) as $linha) {
        echo "<br>";
        echo "NF: " .$linha['nf'] . "<br>";
        echo "Data: " . $linha['data']. "<br>";
        echo "Valor total R$: " .$linha['valor_total'] ."<br>";

        $nota = $linha['nf'];
        $consulta2 = "SELECT * FROM itens_nf WHERE num_nf = '$nota'";

        foreach ($conexao -> query($consulta2) as $linha2) {
            echo "ID: " . $linha2['id'] . " / ";
            echo "CodProduto: " .$linha2['cod_produto'] . " / ";

            $codigo = $linha2['cod_produto'];
            $consulta3 = "SELECT * FROM produtos WHERE id = '$codigo'";

            foreach ($conexao -> query($consulta3) as $linha3) {
                echo "Nome: " .$linha3['nome'] ." / ";
                echo "Valor Unit R$: " . $linha3['preco'] . " / ";
    
            }

            echo "Qtde: " . $linha2['qtde'] . " / ";
            echo "Subtotal R$: " . $linha2['subtotal'] ."<br>";
        }
        echo "<hr>";
    }
    echo "<br>";
?>
<p class="centro"><a href="index.php" class="btn btn-dark btn lg"> VOLTAR INICIO</a></p>

        </div>
    </div>
</div>