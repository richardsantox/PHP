<!DOCTYPE html>
<html>

<?php
    session_start();
    include 'conecta.php';
    include 'cabecalho.php';
    if (($_SESSION['nivel']) != 2) {
    header("Location: aviso.php");
    }
?>


<div class="container">
    <br>
            <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">&nbsp; Insira os dados do produto</h5>

    <form class="centro" action="inserir_produto.php" method="post">
                         <div class="form-group"> 
                            <label for="nome-produto">NOME</label>
                            <input class="form-control" type="text" name="nomeP"><br>
                        </div>

                          <div class="form-group"> 
                            <label for="preco-produto">PREÇO</label>
                            <input class="form-control" type="text" name="precoP" value="R$0.00"><br>
                        </div>

        <hr>
        <input type="submit" value="Cadastar" class="btn btn-dark btn lg">
    </form>

</body>

</html>