<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="../js/bootstrap.bundle.js"></script>
	<script type="text/javascript" src="../js/bootstrap.js"></script>
	<script src="https://kit.fontawesome.com/93d2e1d254.js" crossorigin="anonymous"></script>
</head>

<body>
	<nav class="navbar navbar-dark bg-dark">
		<a class="navbar-brand centro" href="index.php">
			<h1>PAPELARIA COMPRAS</h1>
		</a>
			
		<a href="logout.php" class="btn btn-warning" role="button"><i class="far fa-user-circle"></i>Logout</a> 

	</nav>